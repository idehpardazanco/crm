<?php

namespace Modules\Monitoring\app\Exceptions;

use Throwable;
use Modules\Monitoring\app\Models\SystemLog;

/**
 * Global exception logger
 */
class ExceptionLogger
{
    public static function log(Throwable $e): void
    {
        SystemLog::create([
            'level' => 'error',
            'message' => $e->getMessage(),
            'context' => [
                'file' => $e->getFile(),
                'line' => $e->getLine(),
            ],
        ]);
    }
}