<?php

return [
    'name' => 'Interactions',
];
