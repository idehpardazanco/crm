<?php

return [
    'name' => 'Sms',
];
