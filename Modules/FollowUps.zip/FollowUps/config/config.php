<?php

return [
    'name' => 'FollowUps',
];
