<?php

return [
    'name' => 'Contacts',
];
