<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Contacts\\app\\Providers\\ContactsServiceProvider',
    2 => 'Modules\\Core\\app\\Providers\\CoreServiceProvider',
    3 => 'Modules\\FollowUps\\app\\Providers\\FollowUpsServiceProvider',
    4 => 'Modules\\Interactions\\app\\Providers\\InteractionsServiceProvider',
    5 => 'Modules\\Monitoring\\app\\Providers\\MonitoringServiceProvider',
    6 => 'Modules\\Orders\\app\\Providers\\OrdersServiceProvider',
    7 => 'Modules\\Settings\\app\\Providers\\SettingsServiceProvider',
    8 => 'Modules\\Sms\\app\\Providers\\SmsServiceProvider',
    9 => 'Modules\\Users\\app\\Providers\\UsersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Contacts\\app\\Providers\\ContactsServiceProvider',
    2 => 'Modules\\Core\\app\\Providers\\CoreServiceProvider',
    3 => 'Modules\\FollowUps\\app\\Providers\\FollowUpsServiceProvider',
    4 => 'Modules\\Interactions\\app\\Providers\\InteractionsServiceProvider',
    5 => 'Modules\\Monitoring\\app\\Providers\\MonitoringServiceProvider',
    6 => 'Modules\\Orders\\app\\Providers\\OrdersServiceProvider',
    7 => 'Modules\\Settings\\app\\Providers\\SettingsServiceProvider',
    8 => 'Modules\\Sms\\app\\Providers\\SmsServiceProvider',
    9 => 'Modules\\Users\\app\\Providers\\UsersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);