<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Contacts\\app\\Providers\\ContactsServiceProvider',
    2 => 'Modules\\Core\\app\\Providers\\CoreServiceProvider',
    3 => 'Modules\\Monitoring\\app\\Providers\\MonitoringServiceProvider',
    4 => 'Modules\\Orders\\app\\Providers\\OrdersServiceProvider',
    5 => 'Modules\\Settings\\app\\Providers\\SettingsServiceProvider',
    6 => 'Modules\\Sms\\app\\Providers\\SmsServiceProvider',
    7 => 'Modules\\Users\\app\\Providers\\UsersServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Auth\\app\\Providers\\AuthServiceProvider',
    1 => 'Modules\\Contacts\\app\\Providers\\ContactsServiceProvider',
    2 => 'Modules\\Core\\app\\Providers\\CoreServiceProvider',
    3 => 'Modules\\Monitoring\\app\\Providers\\MonitoringServiceProvider',
    4 => 'Modules\\Orders\\app\\Providers\\OrdersServiceProvider',
    5 => 'Modules\\Settings\\app\\Providers\\SettingsServiceProvider',
    6 => 'Modules\\Sms\\app\\Providers\\SmsServiceProvider',
    7 => 'Modules\\Users\\app\\Providers\\UsersServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);