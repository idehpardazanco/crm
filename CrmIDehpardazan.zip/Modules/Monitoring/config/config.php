<?php

return [
    'name' => 'Monitoring',
];
