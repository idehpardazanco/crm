<?php

return [
    'name' => 'Settings',
];
